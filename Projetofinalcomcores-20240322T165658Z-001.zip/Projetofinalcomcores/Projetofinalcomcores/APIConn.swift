//
//  Types.swift
//  ProjetoFinal
//
//  Created by Turma01-4 on 19/03/24.
//

import Foundation

struct Alternative: Codable, Hashable {
    var text: String
    var correct: Bool
}

struct Question: Codable {
    var _id: String
    var _rev: String
    
    var text: String
    var alternatives: [Alternative]
}

struct Answer: Codable {
    var _id: String
    var _rev: String
    
    var question: String
    var choice: Int
    var correct: Bool
}

struct ToQuestion: Encodable {
    var text: String
    var alternatives: [Alternative]
}

struct ToAnswer: Encodable {
    var question: String
    var choice: Int
    var correct: Bool
}

class ServerData: ObservableObject{
    @Published var questions: [Question] = []
    @Published var results: [Answer] = []
    
    @Published var total = 0
    @Published var right = 0
    
    @Published var wrong: [String: Int] = [:]
    @Published var solved: [String: Int] = [:]
    
    @Published var gra : [graph] = []
    
    struct graph {
        var question : String
        var times : Int
        var type : String
    }
    
    
//    func mapToGraph(){
//        for (k, v) in tried {
//            print(k)
//            print(v)
//            print(solved[k]!)
//            gra.append(graph(question: k, times: v, corrects: solved[k]!))
//        }
//    }
    
    func get_pos(a: String) -> Int{
        var arr: [String] = []
        for (q) in questions{
            arr.append(q._id)
        }
        
        var i = 0
        for v in arr {
            if (v == a) {
                return i+1
            }
            i += 1
        }
        
        return i
    }
    
    func count_wrong(results: [Answer]) -> [String: Int] {
        var dict: [String: Int] = [:]
       
        for (a) in results {
            dict.updateValue(0, forKey: a.question)
        }
        
        for (a) in results {
            if (!a.correct) {
                total += 1
                dict[a.question]! += 1
            }
        }
        
        for (k, v) in dict {
            gra.append(graph(question: "Question \(get_pos(a: k))", times: v, type: "Wrong"))
        }
        return dict
    }
    
    func count_solved(results: [Answer]) -> [String: Int] {
        var dict: [String: Int] = [:]
        for (a) in results {
            dict.updateValue(0, forKey: a.question)
        }
        for (a) in results {
            if (a.correct) {
                total += 1
                right += 1
                dict[a.question]! += 1
            }
        }
        
        for (k, v) in dict {
            gra.append(graph(question: "Question \(get_pos(a: k))", times: v, type: "Correct"))
        }
        return dict
    }
    
    func get_questions(){
        guard let url = URL(string: "http://192.168.128.23:1880/get_questions") else {return}
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else {return}
            
            do {
                let parsed = try JSONDecoder().decode([Question].self, from: data)
                DispatchQueue.main.async {
                    // print(parsed)
                    self?.questions = parsed
                }
            } catch {print(error)}
        }
        task.resume()
    }
    
    func post_question(question: String,
                       a1: Alternative,
                       a2: Alternative,
                       a3: Alternative,
                       a4: Alternative,
                       a5: Alternative) {
        
        guard let url = URL(string: "http://192.168.128.23:1880/post_question") else {
            print("Error: cannot create URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Headers must specify that the HTTP request body is JSON-encoded
        var headers = request.allHTTPHeaderFields ?? [:]
        headers["Content-Type"] = "application/json"
        request.allHTTPHeaderFields = headers
        
        let questionToUpload = ToQuestion(
            text: question,
            alternatives: [a1, a2, a3, a4, a5]
        )
        
        let encoder = JSONEncoder()
        
        do {
            let jsonData = try encoder.encode(questionToUpload)
            request.httpBody = jsonData
            print("jsonData: ", String(data: request.httpBody!, encoding: .utf8) ?? "no body data")
        } catch {
            print("Error encoding to JSON: \(error.localizedDescription)")
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error to send resource: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                print("Error to send resource: invalid response")
                return
            }
            
            if httpResponse.statusCode == 200 {
                print("Resource POST successfully")
            } else {
                print("Error POST resource: status code \(httpResponse.statusCode)")
            }
        }
        task.resume()
    }
    
    func remove_question(toDelete: Question){
        guard let url = URL(string: "http://192.168.128.23:1880/remove_question") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        do {
            let data = try JSONEncoder().encode(toDelete)
            
            request.httpBody = data
        } catch {
            print("Error encoding to JSON: \(error.localizedDescription)")
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error deleting resource: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                print("Error deleting resource: invalid response")
                return
            }
            
            if httpResponse.statusCode == 200 {
                print("Resource deleted successfully")
            } else {
                print("Error deleting resource: status code \(httpResponse.statusCode)")
            }
        }
        
        task.resume()
    }
    
    func post_result(q1: Question,
                     a: Alternative,
                     chosen: Int){
        guard let url = URL(string: "http://192.168.128.23:1880/post_result") else {
            print("Error: cannot create URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        // Headers must specify that the HTTP request body is JSON-encoded
        var headers = request.allHTTPHeaderFields ?? [:]
        headers["Content-Type"] = "application/json"
        request.allHTTPHeaderFields = headers
        
        let answerToUpload = ToAnswer(
            question: q1._id,
            choice: chosen,
            correct: a.correct
        )
        let encoder = JSONEncoder()
        do {
            let jsonData = try encoder.encode(answerToUpload)
            request.httpBody = jsonData
            print("jsonData: ", String(data: request.httpBody!, encoding: .utf8) ?? "no body data")
        } catch {
            print("Error encoding to JSON: \(error.localizedDescription)")
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error to send resource: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                print("Error to send resource: invalid response")
                return
            }
            
            if httpResponse.statusCode == 200 {
                print("Resource POST successfully")
            } else {
                print("Error POST resource: status code \(httpResponse.statusCode)")
            }
        }
        task.resume()
    }
    
    func get_results(){
        guard let url = URL(string: "http://192.168.128.23:1880/get_results")else {return}
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else {return}
            
            do {
                let parsed = try JSONDecoder().decode([Answer].self, from: data)
                DispatchQueue.main.async {
                    self?.get_questions()
                    self?.gra = []
                    self?.total = 0
                    self?.right = 0
                    self?.wrong = (self?.count_wrong(results: parsed))!
                    self?.solved = (self?.count_solved(results: parsed))!
                    self?.gra.sort { $0.question < $1.question }
                    self?.results = parsed
                }
            } catch {print(error)}
        }
        task.resume()
    }
    
    func clear_results(){
        guard let url = URL(string: "http://192.168.128.23:1880/clear_results") else {return}

        
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else { return }
            print("cleared results")
        }
        
        task.resume()
    }

}
