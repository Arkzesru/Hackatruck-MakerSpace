//
//  AdicionarQuestoes.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 19/03/24.
//

import SwiftUI

struct AdicionarQuestoes: View {
    @StateObject var server = ServerData()
    @State var text : String = ""
    @State var alternativas = [Alternative] (repeating: Alternative(text: "", correct: false), count : 5)
    @State var answer : Int = 1
    
    var body: some View {
        ZStack{
            VStack {
                
                TextField("Titulo da pergunta", text: $text, axis: .vertical)
                
                    .multilineTextAlignment(.center)
                    .frame(width: 325,height: 120)
                    .background(corDeFundoPerguntas)
                    .overlay(RoundedRectangle(cornerRadius: 4).stroke(corBotoesPicker, lineWidth:2))
                    .offset(CGSize(width: 0.0, height: -10.0))
                
                ForEach(alternativas.indices, id: \.self) { index in
                    HStack {
                        Text("#\(index+1)")
                            .frame(width: 50, height: 50)
                            .background(corDeFundoPerguntas)
                            .overlay(RoundedRectangle(cornerRadius: 4).stroke(corBotoesPicker, lineWidth: 2))
                        
                        TextField(text:$alternativas[index].text){
                            Text("Alternativa")
                        }
                        .multilineTextAlignment(.center)
                        .frame(width: 270,height: 50)
                        .background(corDeFundoPerguntas)
                        .overlay(RoundedRectangle(cornerRadius: 4).stroke(corBotoesPicker, lineWidth: 2))

                    }
                    
                }
                Spacer()
                    .frame(width: 0, height: 20)
                
                Text("Selecione a alternativa correta")
                    .font(Font.system(size: 20))
                    Picker("Alternativa Correta", selection: $answer){
                        Text("1").tag(1)
                        
                        Text("2").tag(2)
                        Text("3").tag(3)
                        Text("4").tag(4)
                        Text("5").tag(5)
                    }
                    .accentColor(.black)
                    .frame(width: 50,height: 40)
                    .background(corBotoes)
                    .cornerRadius(8)
                    
                
                    
                    Button("Enviar") {
                        alternativas[answer-1].correct = true
                        server.post_question(
                            question: text,
                            a1: alternativas[0],
                            a2: alternativas[1],
                            a3: alternativas[2],
                            a4: alternativas[3],
                            a5: alternativas[4])
                        
                        alternativas = [Alternative] (repeating: Alternative(text: "", correct: false), count : 5)
                        text = ""
                        answer = 1
                    }
                    .font(Font.system(size: 25))
                    .foregroundColor(.black)
                    .frame(width: 150,height: 60)
                    .background(corBotoes)
                    .cornerRadius(8)
                
            }
            .zIndex(2)
            
        
            
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(corDeFundo)
    }
}

#Preview {
    AdicionarQuestoes()
}
