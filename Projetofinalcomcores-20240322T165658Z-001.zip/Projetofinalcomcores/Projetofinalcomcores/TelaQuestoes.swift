//
//  AlunoEspera.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 15/03/24.
//

import SwiftUI

struct TelaQuestoes: View {
    @StateObject var server = ServerData()
    @State private var currentQuestionIndex = 0
    @State private var selectedAlternativeIndex: Int? = nil
    @State private var isAnswerCorrect: Bool? = nil
    @State private var isAnsweredCorrectly: Bool = false
    @State private var isAnswered: Bool = false
    @State private var allQuestionsAnswered: Bool = false
    
    var wrongAnswerColor: Color = Color.init(red: 1.0, green: 0.4, blue: 0.4);
    
    var body: some View {
        VStack{
            if server.questions.isEmpty {
                Text("Carregando questões...")
            } else { 
                if allQuestionsAnswered {
                    VStack {
                        Text("Parabéns!")
                            .font(.title)
                            .padding()
                        
                        Image(systemName: "trophy")
                            .resizable()
                            .foregroundStyle(.white)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .padding()
                    }
                    .foregroundColor(.white)
                    .shadow(color: .yellow, radius: 10)
                    .padding()
                    .cornerRadius(20)
                    .padding()
                } else {
                    Text(server.questions[currentQuestionIndex].text)
                        .font(.title2)
                        .padding()
                    
                    VStack{
                        ForEach(server.questions[currentQuestionIndex].alternatives.indices, id: \.self) { index in
                            Button(action: {
                                if !isAnswered {
                                    server.post_result(
                                        q1: server.questions[currentQuestionIndex],
                                        a: server.questions[currentQuestionIndex].alternatives[index], 
                                        chosen: index
                                    )
                                    isAnswered = true
                                }
                                if !isAnsweredCorrectly {
                                    self.selectedAlternativeIndex = index
                                    self.isAnswerCorrect = server.questions[self.currentQuestionIndex].alternatives[index].correct
                                    self.isAnsweredCorrectly = self.isAnswerCorrect == true
                                }
                                
                                if index == server.questions[currentQuestionIndex].alternatives.count - 1 {
                                    checkAllQuestionsAnswered()
                                }
                            }) {
                                Text(server.questions[currentQuestionIndex].alternatives[index].text)
                                    .padding()
                                    .foregroundColor(index == self.selectedAlternativeIndex ? .white : .primary)
                            }
                            .frame(width: 350, height: 45)
                            .background(getBackgroundColor(for: index))
                            .cornerRadius(10)
                            .padding(.bottom, 5)
                            .disabled(isAnsweredCorrectly && index != selectedAlternativeIndex)
                        }
                        
                        Button(action: {
                            self.nextQuestion()
                            isAnswered = false
                        }) {
                            Text("Next")
                                .padding()
                                .background(corBotoes)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .padding(.top, 20)
                        .disabled(selectedAlternativeIndex == nil || !isAnsweredCorrectly)
                        
                    }
                }
            }
            
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(corDeFundoQuestoes)
        .onAppear {
            server.get_questions()
        }
    }
    
    func nextQuestion() {
        if currentQuestionIndex < server.questions.count - 1 {
            currentQuestionIndex += 1
            selectedAlternativeIndex = nil
            isAnswerCorrect = nil
            isAnsweredCorrectly = false
        }
        else {
            checkAllQuestionsAnswered()
        }
    }
    
    func checkAllQuestionsAnswered() {
        allQuestionsAnswered = currentQuestionIndex == server.questions.count - 1
    }
    
    
    func getBackgroundColor(for index: Int) -> Color {
        guard let selectedAlternativeIndex = selectedAlternativeIndex else {
            return Color.white
        }
        
        if index == selectedAlternativeIndex {
            return isAnswerCorrect == true ? Color.green : wrongAnswerColor
        } else if server.questions[currentQuestionIndex].alternatives[index].correct && isAnsweredCorrectly && isAnswerCorrect == true {
            return Color.green
        } else if !server.questions[currentQuestionIndex].alternatives[index].correct && isAnsweredCorrectly && isAnswerCorrect == true {
            return wrongAnswerColor
        } else {
            return Color.white
        }
    }
}

#Preview {
    TelaQuestoes()
}

