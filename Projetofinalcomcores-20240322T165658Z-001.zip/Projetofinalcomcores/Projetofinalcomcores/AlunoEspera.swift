//
//  AlunoEspera.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 15/03/24.
//

import SwiftUI

struct AlunoEspera: View {
    @State private var id = "1233"
    
    var body: some View {
        NavigationStack{
            ZStack{
                VStack{
                    Text("Entrar na sala")
                        .font(.title)
                        .foregroundColor(corLetrasEspera)
                        .fontWeight(.bold)
                        .padding()
                    
                    VStack{
                        TextField("Id da sala", text: $id)
                            .multilineTextAlignment(.center)
                            .frame(width: 225,height: 50)
                            .overlay(Rectangle().stroke(corContorno, lineWidth: 1))
                        
                        NavigationLink("ENTRAR", destination: TelaQuestoes())
                            .frame(width: 225, height: 40)
                            .background(corDoBotaoEspera)
                            .foregroundColor(corLetrasEspera)
                        
                    }
                    .frame(width: 250,height: 120)
                    .background(.regularMaterial)
                    .cornerRadius(10)
                    
                }
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(corDeFundo)
        }
    }
}

#Preview {
    AlunoEspera()
}
