//
//  ProfessorHome.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 15/03/24.
//

import SwiftUI

struct DefaultProfessorRectangle : View {
    var w : CGFloat?
    var h : CGFloat?
    
    var body : some View {
        
        Rectangle()
            .frame(width: w, height: h)
            .foregroundColor(corBotoes)
            .cornerRadius(4)

    }
}

struct QuestionButton : View {
    var mode : String?
    var w : CGFloat? = 165
    var h : CGFloat? = 120
    
    var body: some View{
        Text("\(mode!) Questões")
            .font(.headline)
            .foregroundColor(corLetrasProf)
            .background{
                DefaultProfessorRectangle(w: w!, h: h!)
            }.frame(width: w!, height: h!)
            
            
    }
}

struct ProfessorHome: View {
    @StateObject var server = ServerData()
    @State var nomeProfessor : String = " "
    @State var search : String = "Algoritimos em swift"
    @State var modulers : String = "n01"
    @State var shouldPresentSheet : Bool = false
    var body: some View {
        NavigationStack{
            VStack{
                VStack {
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .padding(2)
                        .foregroundColor(corBotaoProf)
                    Text("Bem-vindo, " + nomeProfessor)
                        .font(.title)
                        .foregroundStyle(corBotaoProf)
                }
                .frame(width: 375, height:200)
                .background(corQuinta)
                .offset(CGSize(width: 0, height: -100))
                
                VStack {
                    NavigationLink("Iniciar Teste", destination: Resultados())
                        .font(.title)
                        .textCase(/*@START_MENU_TOKEN@*/.uppercase/*@END_MENU_TOKEN@*/)
                        .foregroundColor(corLetrasProf)
                        .frame(width: 320, height: 120, alignment: .center)
                        .padding(10)
                        .background(corBotoes)
                        .cornerRadius(4)
            
                HStack {
                    NavigationLink{AdicionarQuestoes()}
                label: {QuestionButton(mode: "Adicionar\n")}
                        .zIndex(2)
                    
                    NavigationLink{DeletarQuestoes()}
                label: {QuestionButton(mode: "Excluir\n")}
                        .zIndex(2)
                        
                }
            }
                .offset(CGSize(width: 0, height: -90))
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(corDeFundo)
        }.onAppear(){
            server.clear_results()
        }
       
    }
}

#Preview {
    ProfessorHome()
}
