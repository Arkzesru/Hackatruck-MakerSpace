//
//  Resultados.swift
//  ProjetoFinal3
//
//  Created by Turma01-4 on 21/03/24.
//

import SwiftUI
import Charts

struct Resultados: View {
    @StateObject var server = ServerData()
    
    
    var body: some View {
        VStack{
            Chart{
                ForEach(server.gra, id: \.question){ a in
                    BarMark(
                        x: PlottableValue.value("Questao", a.question),
                        y: PlottableValue.value("Tentados", a.times)
                    ).foregroundStyle(by: .value("Acertos/Erros", a.type))
                        .position(by: .value("Acertos/Erros", a.type))
                    
                }
                
            }.chartForegroundStyleScale([
                "Correct" : Color(.blue),
                "Wrong": Color(.red)
            ])
            .padding()
            .chartScrollableAxes(.horizontal)
            
            Text("Análise").font(.title)
            if (server.right >= server.total - 4){
                Text("Ótima aula, os alunos entenderam!")
            }
            else if (server.right > server.total - server.right){
                Text("Alguns alunos não entenderam, reforce o conteúdo")
            }
            else{
                Text("Os alunos não entenderam, revise o conteúdo")
            }
            
            Button("Atualizar"){
                server.get_questions()
                
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false){_ in
                    server.get_results()
                    
                }
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .backgroundStyle(corDeFundo)
        .onAppear(){
            server.get_questions()
            
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false){_ in 
                server.get_results()
                
            }
        }
    }
}

#Preview {
    Resultados()
}
