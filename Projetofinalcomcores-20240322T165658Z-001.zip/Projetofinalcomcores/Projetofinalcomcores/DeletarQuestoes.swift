//
//  DeletarQuestoes.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 18/03/24.
//

import SwiftUI

struct deleteconfirm: Identifiable {
    var id: String { title }
    let title: String
    let description: String
}

struct DeletarQuestoes: View {
    @StateObject var server = ServerData()
    @State private var showAlert = false
    @State var selected : Question?
    @State private var delete = deleteconfirm(title: "ATENÇÃO!", description: "Tem certeza que gostaria de excluir essa questão?")
    
    var body: some View {
        VStack{
                Text("Deletar Questões")
                    .multilineTextAlignment(.center)
                    .font(.title)
                    .bold()
                    .shadow(radius: 30)
                    .foregroundColor(.white)
                    .padding()
            Spacer(minLength: 35)
            
            List{
                
                ForEach(server.questions, id: \._id) { question in
                    let index = server.questions.firstIndex(where: { $0._id == question._id }) ?? 0
                    HStack{
                        Text("#\(index + 1) - \(question.text)")
                    }
                }
                .onDelete { indexSet in
                    showAlert = true
                    selected = server.questions[indexSet.first!]
                }
            }
            .scrollContentBackground(.hidden)
            .frame(maxWidth: 300, maxHeight: .infinity)
            .listStyle(.plain)
            .shadow(radius: 10)
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text(delete.title),
                    message: Text(delete.description),
                    primaryButton: .default(Text("Confirmar")) {
                        if let selectedQuestion = selected {
                            server.remove_question(toDelete: selectedQuestion)
                            if let index = server.questions.firstIndex(where: {$0._id == selectedQuestion._id}) {
                                server.questions.remove(at: index)
                            }
                        }
                    },
                    secondaryButton: .cancel(Text("Cancelar"))
                )
            }
            .frame(maxWidth: .infinity)
            .onAppear{
                server.get_questions()
            }
        }            .background(Color.cordefundo)

    }
}

#Preview {
    DeletarQuestoes()
}
