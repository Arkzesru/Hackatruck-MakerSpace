//
//  ProjetofinalcomcoresApp.swift
//  Projetofinalcomcores
//
//  Created by Turma01-3 on 21/03/24.
//

import SwiftUI

@main
struct ProjetofinalcomcoresApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
