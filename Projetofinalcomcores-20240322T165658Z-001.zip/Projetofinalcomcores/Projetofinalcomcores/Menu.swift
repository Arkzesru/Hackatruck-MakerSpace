//
//  ContentView.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 15/03/24.
//

import SwiftUI

struct Menu: View {
    @State private var name : String = " "

    var body: some View {
        NavigationStack{
            ZStack {
                VStack {
                    Text("Tendeu?")
                        .foregroundColor(corContorno)
                        .font(.custom("LOKICOLA", size: 60))
                        .offset(CGSize(width: 0, height: -130))
            
                    
                    TextField("Digite Seu Nome", text: $name, axis: .horizontal)
                        .multilineTextAlignment(.center)
                        .frame(width: 250,height: 40)
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(corContorno, lineWidth: 2))
                        .offset(CGSize(width: 0, height: -60))
                    
                    NavigationLink("Alunos", destination: AlunoEspera())
                        .font(.custom("courier", size: 38))
                        .foregroundColor(corContorno)
                        .frame(width: 240,height: 70)
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(corContorno, lineWidth: 4))
                        .cornerRadius(15)
                    
                    NavigationLink("Professor", destination: ProfessorHome(nomeProfessor: name))
                        .font(.custom("courier", size: 38))
                        .foregroundColor(corContorno)
                        .frame(width: 240,height: 70)
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(corContorno, lineWidth: 4))
                        .cornerRadius(15)
                        }
            
        
                
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(corDeFundo)
            }
        .accentColor(.white)
        }
       
    }

#Preview {
    Menu()
}
