//
//  ColorPalette.swift
//  ProjetoFinal
//
//  Created by Turma01-3 on 15/03/24.
//

import Foundation
import SwiftUI

// Cordefundo
// Cor1
// Cor2
// Cor3
// Cor4
// Cor5
// Cor6
// CorAzul1
// CorAzul2
// CorAzul3
// CorAzul4
// CorAzul5


// Original
var corDeFundo : Color = Color("Cordefundo")
var corBotaoInicial : Color = Color("Cor1")
var corSegunda : Color = Color("Cor2")
var corContorno : Color = Color("Cor4")
var corLetrasEspera : Color = Color("Cor4")
var corBotoes : Color = Color("Cor3")
var corQuinta : Color = Color("Cor5")
var corLetrasProf : Color = Color("Cor6")

// Gabriel
var corDeFundoEspera : Color = Color("Cordefundo")
var corDoBotaoEspera : Color = Color("Cordefundo")
var corDeFundoQuestoes : Color = Color("Cordefundo")

//  Carlos
var corDeFundoAlunos : Color = Color("Cor5")
var corBotaoProf : Color = Color("Cor1")
var corPickr : Color = Color("Cor1")
var corDeFundoPerguntas : Color = Color("Cor1")
var corBotoesPicker : Color = Color("Cor4")
var corCapaP : Color = Color("Cor2")
var corDeFundoProf : Color = Color("Cor2")


